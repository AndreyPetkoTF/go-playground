package model

class Post {

	public function addRate(int $stars)
	{
		$stars //
		$this->rate //
		$this->rateCount //

		$this->rate = $newCalculatedRate;
		$this->rateCount++
	}
}

