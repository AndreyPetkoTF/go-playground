package model

class Comment {

}
