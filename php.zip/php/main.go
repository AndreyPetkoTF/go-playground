package php


class RoutesHandler {
	function handle() {
		if (url === "/posts" && method === "GET") {
			$posts = $this->postRepository->getPosts();

			json_encode($posts);
		}

		if (url == "/post/{id}" && method === "PATCH") {
			-> request_body

			$rate = request_body['rate']; // 5

			if ($rate < 0 || $rate > 5) {
				throw new Exception()
			}

			$post = $this->postRepository->getPost($id)
			$post->addRate(5);

			$this-postRepository->save($post);
		}
	}
}
