package repository

interface CommentRepositoryInterface {
	getByPost(Post $post): []Comment
	save(Comment $comment): void
}


class MysqlCommentRepository() {

	function __contruct(private DBConnetion $connection) {}

	public function getByPost(Post $post): []Comment {
		$commentArray = $this->connection->select("dfdfdf WHERE post_id = %s", $post->getId())

		return array_map(function($commentData) {
			return new Comment($commentData)
		}, $commentArray)
	}

	public function save(Comment $comment) {
		$this->connection->("INSERT")
	}

	public function update(Comment $comment) {

		$this->connection->("UPDATE WHERE id = comment_id")
	}
}